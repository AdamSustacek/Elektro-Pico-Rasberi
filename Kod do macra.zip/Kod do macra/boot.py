# boot.py
# ---------------------------------------------------------
# Tento soubor běží JEN při startu/resetu Pica (ne při
# pouhém uložení code.py). Po nahrání je potřeba Pico
# odpojit a znovu připojit (nebo dvakrát rychle stisknout
# reset), aby se změna projevila.
#
# Povoluje USB HID zařízení:
#   - Keyboard (klávesnice)
#   - Consumer Control (hlasitost, jas, media klávesy)
#
# Bez tohoto souboru (nebo pokud chybí Consumer Control
# v jeho nastavení) systém prostě nemá kam poslat příkazy
# pro hlasitost/jas - proto to bez něj vypadá, že "nic
# nedělá", i když je kód v code.py správně.
# ---------------------------------------------------------

import usb_hid

usb_hid.enable(
    (usb_hid.Device.KEYBOARD, usb_hid.Device.CONSUMER_CONTROL)
)

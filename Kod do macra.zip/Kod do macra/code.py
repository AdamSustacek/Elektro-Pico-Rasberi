# code.py
# ---------------------------------------------------------
# Firmware pro makro pad (RP2040 / CircuitPython).
# Dvě přepínatelné stránky:
#   0 = NUMPAD + JAS   (enkodér mění jas)
#   1 = ZKRATKY        (enkodér mění hlasitost)
# Přepínání tlačítkem [11] (edge-detect, s debounce).
# ---------------------------------------------------------

import board
import digitalio
import time
import busio
import neopixel
import adafruit_ssd1306
import struct
import rotaryio
import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode
from adafruit_framebuf import BitmapFont
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode


# ===========================================================
# KLÁVESOVÉ MAPY
# Fyzické rozmístění tlačítek (podle button_read() níže):
#
#   [0]  [4]  [8]
#   [1]  [5]  [9]
#   [2]  [6]  [10]
#   [3]  [7]  [11] <- [11] je tlačítko pro přepínání stránek
#
# Každý záznam: index_tlacitka -> tuple keycodů, které se
# mají držet stisknuté (1 klávesa = plain key, 2+ = kombinace
# s modifikátorem, např. CTRL + C).
# ===========================================================

# --- Stránka 1: NUMPAD -------------------------------------
# Čísla se posílají přes Shift + horní řada (na CZ layoutu jsou
# bez Shiftu na těchto klávesách háčky/čárky, se Shiftem čísla).
NUMPAD_MAP = {
    0:  (Keycode.SHIFT, Keycode.ZERO),
    1:  (Keycode.SHIFT, Keycode.ONE),
    2:  (Keycode.SHIFT, Keycode.TWO),
    3:  (Keycode.SHIFT, Keycode.THREE),
    4:  (Keycode.SHIFT, Keycode.FOUR),
    5:  (Keycode.SHIFT, Keycode.FIVE),
    6:  (Keycode.SHIFT, Keycode.SIX),
    7:  (Keycode.SHIFT, Keycode.SEVEN),
    8:  (Keycode.SHIFT, Keycode.EIGHT),
    9:  (Keycode.SHIFT, Keycode.NINE),
    10: (Keycode.BACKSPACE,),
    # 11 = přepínač stránek, zde se nepoužívá
}

NUMPAD_LABEL = "NUMPAD + JAS"

# --- Stránka 2: ZKRATKY (Ctrl + X) --------------------------
SHORTCUT_MAP = {
    0:  (Keycode.CONTROL, Keycode.C),   # Zpět (Undo)
    1:  (Keycode.CONTROL, Keycode.V),   # Znovu (Redo)
    2:  (Keycode.CONTROL, Keycode.X),   # Najít
    3:  (Keycode.CONTROL, Keycode.Z),   # Vyjmout
    4:  (Keycode.CONTROL, Keycode.Y),   # Kopírovat
    5:  (Keycode.CONTROL, Keycode.A),   # Vložit
    6:  (Keycode.CONTROL, Keycode.S),   # Vybrat vše
    7:  (Keycode.CONTROL, Keycode.P),   # Uložit
    8:  (Keycode.CONTROL, Keycode.F),   # Tisk
    9:  (Keycode.CONTROL, Keycode.B),   # Nový
    #10: (Keycode.CONTROL, Keycode.),   # Zavřít
    # 11 = přepínač stránek, zde se nepoužívá
}

SHORTCUT_LABEL = "ZKRATKY + ZVUK"


# ===========================================================
# HARDWARE
# ===========================================================

# --- Rychlejší vykreslování textu na OLED (bypass pomalé knihovní verze) ---
class FastBitmapFont(BitmapFont):
    def draw_char(self, char, x, y, framebuffer, color, size=1):
        # Rychlá cesta funguje jen když je y zarovnané na 8 px a size == 1
        if size != 1 or (y % 8) != 0:
            return super().draw_char(char, x, y, framebuffer, color, size)
        for cx in range(self.font_width):
            self._font.seek(2 + (ord(char) * self.font_width) + cx)
            try:
                line = struct.unpack("B", self._font.read(1))[0]
            except RuntimeError:
                continue
            framebuffer.buf[framebuffer.width * (y >> 3) + x + cx] |= line


np = neopixel.NeoPixel(board.GP5, 4, auto_write=False)
kbd = Keyboard(usb_hid.devices)
cc = ConsumerControl(usb_hid.devices)

i2c = busio.I2C(scl=board.GP1, sda=board.GP0, frequency=1000000)
display = adafruit_ssd1306.SSD1306_I2C(128, 64, i2c)
display._font = FastBitmapFont()
display.invert = False
display.contrast = 1

# Řádkové výstupy (aktivují se postupně)
rw1 = digitalio.DigitalInOut(board.GP9); rw1.direction = digitalio.Direction.OUTPUT
rw2 = digitalio.DigitalInOut(board.GP8); rw2.direction = digitalio.Direction.OUTPUT
rw3 = digitalio.DigitalInOut(board.GP7); rw3.direction = digitalio.Direction.OUTPUT
rw4 = digitalio.DigitalInOut(board.GP6); rw4.direction = digitalio.Direction.OUTPUT

# Sloupcové vstupy (pull-down)
cl1 = digitalio.DigitalInOut(board.GP4); cl1.direction = digitalio.Direction.INPUT; cl1.pull = digitalio.Pull.DOWN
cl2 = digitalio.DigitalInOut(board.GP3); cl2.direction = digitalio.Direction.INPUT; cl2.pull = digitalio.Pull.DOWN
cl3 = digitalio.DigitalInOut(board.GP2); cl3.direction = digitalio.Direction.INPUT; cl3.pull = digitalio.Pull.DOWN

enc = rotaryio.IncrementalEncoder(board.GP14, board.GP15)

# Vypnout NeoPixely na startu
for i in range(4):
    np[i] = (0, 0, 0)
np.write()


# ===========================================================
# STAV TLAČÍTEK
# ===========================================================
buttons = [False] * 12  # tlačítka zleva doprava, shora dolů, index 0-11


def button_read():
    """Naskenuje maticovou klávesnici 4x3 a naplní pole buttons[]."""
    rw4.value = True
    buttons[0] = cl1.value
    buttons[4] = cl2.value
    buttons[8] = cl3.value
    rw4.value = False

    rw3.value = True
    buttons[1] = cl1.value
    buttons[5] = cl2.value
    buttons[9] = cl3.value
    rw3.value = False

    rw2.value = True
    buttons[2] = cl1.value
    buttons[6] = cl2.value
    buttons[10] = cl3.value
    rw2.value = False

    rw1.value = True
    buttons[3] = cl1.value
    buttons[7] = cl2.value
    buttons[11] = cl3.value
    rw1.value = False


# ===========================================================
# AKTIVITA DISPLEJE (auto-off)
# ===========================================================
last_activity = time.monotonic()
display_on = True


def reset_activity():
    global last_activity, display_on
    last_activity = time.monotonic()
    if not display_on:
        display.poweron()
        display_on = True


def check_display_timeout(timeout=3.0):
    global display_on
    if display_on and (time.monotonic() - last_activity > timeout):
        display.fill(0)
        display.show()
        display.poweroff()
        display_on = False


# ===========================================================
# PŘEPÍNÁNÍ STRÁNEK (tlačítko 11, s debounce)
# ===========================================================
PAGE_NUMPAD = 0
PAGE_SHORTCUT = 1

current_page = PAGE_NUMPAD
prev_page_button = False
last_page_switch = 0.0
PAGE_SWITCH_DEBOUNCE = 0.25  # sekundy - ignoruje zákmity kontaktu


def update_page_switch():
    """Detekuje náběžnou hranu na tlačítku [11] a přepne stránku."""
    global current_page, prev_page_button, last_page_switch

    now = time.monotonic()
    pressed_now = buttons[11]

    if pressed_now and not prev_page_button:
        if now - last_page_switch > PAGE_SWITCH_DEBOUNCE:
            # Uvolníme všechny klávesy z předchozí stránky, ať nic nezůstane "zaseklé"
            kbd.release_all()
            current_page = PAGE_SHORTCUT if current_page == PAGE_NUMPAD else PAGE_NUMPAD
            last_page_switch = now
            reset_activity()

    prev_page_button = pressed_now


# ===========================================================
# APLIKACE KLÁVESOVÉ MAPY NA AKTUÁLNÍ STAV TLAČÍTEK
# ===========================================================
def apply_keymap(keymap):
    for index, keycodes in keymap.items():
        if buttons[index]:
            kbd.press(*keycodes)
        else:
            kbd.release(*keycodes)


# ===========================================================
# ENKODÉR: jas (stránka NUMPAD) nebo hlasitost (stránka ZKRATKY)
# ===========================================================
last_encoder_position = enc.position


def handle_encoder():
    global last_encoder_position

    position = enc.position
    delta = position - last_encoder_position
    if delta == 0:
        return

    if current_page == PAGE_NUMPAD:
        # Jas obrazovky notebooku (systémový HID příkaz).
        # POZNÁMKA: spousta notebooků (hlavně Windows) tento HID příkaz
        # vůbec nepodporuje - je to omezení OS/ovladače, ne firmwaru.
        if delta > 0:
            cc.send(ConsumerControlCode.BRIGHTNESS_INCREMENT)
        else:
            cc.send(ConsumerControlCode.BRIGHTNESS_DECREMENT)
    else:
        # Hlasitost systému
        if delta > 0:
            cc.send(ConsumerControlCode.VOLUME_INCREMENT)
        else:
            cc.send(ConsumerControlCode.VOLUME_DECREMENT)

    reset_activity()
    last_encoder_position = position


# ===========================================================
# VYKRESLENÍ OLED PODLE AKTUÁLNÍ STRÁNKY
# ===========================================================
def draw_display():
    display.fill(0)
    if current_page == PAGE_NUMPAD:
        display.text(NUMPAD_LABEL, 15, 28, 1)
        display.text("", 10, 42, 1)
    else:
        display.text(SHORTCUT_LABEL, 30, 28, 1)
        display.text("", 8, 42, 1)
    display.show()


# ===========================================================
# HLAVNÍ SMYČKA
# ===========================================================
while True:
    button_read()
    check_display_timeout()

    if any(buttons):
        reset_activity()

    update_page_switch()
    handle_encoder()

    if current_page == PAGE_NUMPAD:
        apply_keymap(NUMPAD_MAP)
    else:
        apply_keymap(SHORTCUT_MAP)

    if display_on:
        draw_display()

    time.sleep(0.01)  # malá pauza kvůli stabilitě skenování matice
